package common_features;

public interface Activities {
	
	 default void games() {
		
	};
	
	default void activity() {
		
	}
	
	public void schoolAttendance();
}
