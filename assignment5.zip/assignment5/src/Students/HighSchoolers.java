package Students;

import common_features.Activities;
import common_features.StudentFeatures;

public class HighSchoolers  extends StudentFeatures implements Activities {

	public HighSchoolers(String name, String email, String phone, String address, String year) {
		super(name, email, phone, address, year);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void schoolAttendance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void studyTime() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void lunchBreak() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void studyBreakTime() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void holiday() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void studentDetail() {
		// TODO Auto-generated method stub
		
	}

}
