package Teachers;

import common_features.Activities;
import common_features.StaffFeatures;

public class HistoryTeacher extends StaffFeatures implements Activities {

	public HistoryTeacher(String name, String phone, String address, String role, String year) {
		super(name, phone, address, role, year);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void breakTime() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void meetingTime() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void holidayTime() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void payCheck() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void teachingTime() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void schoolAttendance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void staffDetail() {
		// TODO Auto-generated method stub
		
	}

}
