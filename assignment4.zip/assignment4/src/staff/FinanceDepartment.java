package staff;

public class FinanceDepartment {
	public String name;
	public String phone;
	public String address;
	public String role;
	public Long departmentId;
	
	public FinanceDepartment(String name, String phone, String address, String role,Long departmentId) {
		super();
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.role = role;
		this.departmentId=departmentId;
	}
	
	public void seeDetail() {
		
	}
	
	public void terminateStaff() {
		
	}
	
	public void montlyPay() {
		
	}
	
	public void overTimePay() {
		
	}
}
