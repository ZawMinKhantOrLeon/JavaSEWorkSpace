package report;

public class UserReport {
	public String report;
	public String departmentId;
	
	
	public UserReport(String report, String departmentId) {
		super();
		this.report = report;
		this.departmentId = departmentId;
	}

	public void addReport() {
		
	}
	
	public void deleteReport() {
		
	}
	
	public void showReport() {
		
	}
}
