package report;

public class StaffReport {
	
	public String report;
	public String departmentId;
	
	
	public StaffReport(String report, String departmentId) {
		super();
		this.report = report;
		this.departmentId = departmentId;
	}

	public void addReport() {
		
	}
	
	public void deleteReport() {
		
	}
	
	public void showReport() {
		
	}
}
