package report;

public class Department {
	
	public Long dId;

	public Department(Long dId) {
		super();
		this.dId = dId;
	}
	
	
}
